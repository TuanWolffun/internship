﻿namespace Quantum {
  public static class EditorDefines {
    public const int AssetMenuPriority               = -1000;
    public const int AssetMenuPriorityConfigurations = AssetMenuPriority + 1;
    public const int AssetMenuPriorityDemo           = AssetMenuPriority + 2;
    public const int AssetMenuPriorityStart          = AssetMenuPriority + 100;
  }
}